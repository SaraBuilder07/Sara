package com.sara.asistente

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

class SaraAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instancia: SaraAccessibilityService? = null
    }

    override fun onServiceConnected() {
        instancia = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        instancia = null
        return super.onUnbind(intent)
    }
}
