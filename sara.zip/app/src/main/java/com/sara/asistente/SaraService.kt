package com.sara.asistente

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

class SaraService : Service() {

    private var reconocedor: SpeechRecognizer? = null
    private val h = Handler(Looper.getMainLooper())
    private var activo = false
    private var ordenHasta = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Estado.log("Falta el permiso del micrófono.")
            stopSelf()
            return START_NOT_STICKY
        }
        iniciarEnPrimerPlano()
        Speaker.init(this)
        if (!activo) {
            activo = true
            Estado.log("Sara está escuchando. Di: \"Sara inicia\"")
            escuchar()
        }
        return START_STICKY
    }

    private fun iniciarEnPrimerPlano() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("sara", "Sara escuchando", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, "sara")
            .setContentTitle("Sara está activa")
            .setContentText("Di \"Sara inicia\" y luego tu orden")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
        if (Build.VERSION.SDK_INT >= 30) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, n)
        }
    }

    private fun escuchar() {
        if (!activo) return
        if (Speaker.hablando) {
            h.postDelayed({ escuchar() }, 700)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Estado.log("Este celular no tiene reconocimiento de voz disponible.")
            return
        }
        reconocedor?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        r.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                val texto = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull() ?: ""
                procesar(texto)
                h.postDelayed({ escuchar() }, 900)
            }

            override fun onError(error: Int) {
                if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                    Estado.log("Falta el permiso del micrófono.")
                    stopSelf()
                    return
                }
                val espera = if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1500L else 400L
                h.postDelayed({ escuchar() }, espera)
            }

            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        reconocedor = r
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-MX")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        r.startListening(i)
    }

    private fun procesar(texto: String) {
        if (texto.isBlank()) return
        val esperando = System.currentTimeMillis() < ordenHasta
        val m = Acciones.ACTIVACION.find(texto)
        when {
            m != null -> {
                ordenHasta = 0L
                val resto = m.groupValues[1].trim()
                if (resto.isEmpty()) {
                    ordenHasta = System.currentTimeMillis() + 10_000
                    responder("Dime.")
                } else {
                    Estado.log("Tú: $resto")
                    responder(Acciones.ejecutar(this, resto))
                }
            }
            esperando -> {
                ordenHasta = 0L
                Estado.log("Tú: $texto")
                responder(Acciones.ejecutar(this, texto))
            }
            else -> {}
        }
    }

    private fun responder(mensaje: String) {
        Estado.log("Sara: $mensaje")
        Speaker.decir(mensaje)
    }

    override fun onDestroy() {
        activo = false
        h.removeCallbacksAndMessages(null)
        reconocedor?.destroy()
        reconocedor = null
        Estado.log("Sara dejó de escuchar.")
        super.onDestroy()
    }
}
