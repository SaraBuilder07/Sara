package com.sara.asistente

object Estado {
    @Volatile
    var oyente: ((String) -> Unit)? = null

    fun log(texto: String) {
        oyente?.invoke(texto)
    }
}
