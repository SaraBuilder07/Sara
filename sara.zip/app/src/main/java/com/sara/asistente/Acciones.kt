package com.sara.asistente

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.provider.ContactsContract
import android.telephony.SmsManager
import java.text.Normalizer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Acciones {

    val ACTIVACION = Regex("(?:sara|zara|sarah)\\W*\\s+inici[ao]\\W*(.*)", RegexOption.IGNORE_CASE)

    private val SMS_REGEX = Regex(
        "(?:manda|mandar|mandale|envia|enviar|envia|enviale|escribe|escribir|escribele)\\s+(?:un\\s+)?(?:mensaje|sms|texto)\\s+a\\s+(.+?)\\s+(?:diciendo|que diga|que dice|que)\\s+(.+)",
        RegexOption.IGNORE_CASE
    )

    fun norm(s: String): String =
        Normalizer.normalize(s.lowercase(Locale("es")), Normalizer.Form.NFD)
            .replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
            .trim()

    fun quitarActivacion(s: String): String =
        ACTIVACION.find(s)?.groupValues?.get(1)?.trim() ?: s.trim()

    fun ejecutar(ctx: Context, original: String): String {
        val t = norm(original).replace(Regex("[,.¡!¿?]"), " ").replace(Regex("\\s+"), " ").trim()
        return try {
            when {
                t.isEmpty() -> "No te escuché."
                t.contains("mensaje") && SMS_REGEX.containsMatchIn(norm(original)) -> mandarMensaje(ctx, original)
                t.startsWith("llama ") || t.startsWith("llamar ") -> llamar(ctx, t)
                t.startsWith("abre ") || t.startsWith("abrir ") || t.startsWith("abra ") -> abrirApp(ctx, t.substringAfter(" "))
                t.contains("linterna") || t.contains("lampara") -> linterna(ctx, !t.contains("apag"))
                t.contains("captura") || t.contains("pantallazo") ->
                    global(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT, "Captura tomada.")
                t.contains("recientes") || t.contains("cierra todo") || t.contains("cerrar todo") ||
                    t.contains("cierra las apps") || t.contains("cerrar apps") || t.contains("cierra las aplicaciones") ->
                    global(AccessibilityService.GLOBAL_ACTION_RECENTS, "Aquí están tus apps recientes. Desliza para cerrarlas.")
                t.startsWith("cierra") || t.startsWith("cerrar") || t.contains("pantalla de inicio") || t == "inicio" ->
                    global(AccessibilityService.GLOBAL_ACTION_HOME, "Listo, estás en el inicio.")
                t.contains("atras") || t.startsWith("regresa") || t.startsWith("vuelve") ->
                    global(AccessibilityService.GLOBAL_ACTION_BACK, "Listo.")
                t.contains("notificaciones") ->
                    global(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS, "Aquí están tus notificaciones.")
                t.contains("bloquea") ->
                    global(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN, "Pantalla bloqueada.")
                t.contains("volumen") || t.contains("silencio") || t.contains("silencia") -> volumen(ctx, t)
                t.contains("que hora") || t.contains("la hora") -> hora()
                t.contains("ayuda") || t.contains("que puedes hacer") -> AYUDA
                t.startsWith("hola") -> "Hola, soy Sara. ¿En qué te ayudo?"
                else -> "No entendí eso. Di ayuda para saber qué puedo hacer."
            }
        } catch (e: Exception) {
            "No pude hacerlo."
        }
    }

    private const val AYUDA =
        "Puedo abrir apps, encender o apagar la linterna, tomar capturas, ir al inicio, ver apps recientes, " +
            "subir o bajar el volumen, llamar a un contacto, mandar mensajes y decirte la hora."

    // Lanza una actividad desde el servicio de accesibilidad si está activo (Android restringe abrir apps desde el fondo)
    private fun lanzar(ctx: Context, intent: Intent) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val c: Context = SaraAccessibilityService.instancia ?: ctx
        c.startActivity(intent)
    }

    private fun global(accion: Int, ok: String): String {
        val s = SaraAccessibilityService.instancia
            ?: return "Necesito que actives mi servicio de accesibilidad en Ajustes."
        return if (s.performGlobalAction(accion)) ok else "No pude hacerlo."
    }

    private fun abrirApp(ctx: Context, nombre: String): String {
        val pm = ctx.packageManager
        val filtro = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(filtro, 0)
        var buscado = norm(nombre)
        for (p in listOf("la ", "el ", "app ", "aplicacion ", "la app de ", "la aplicacion de ")) {
            if (buscado.startsWith(p)) buscado = buscado.removePrefix(p)
        }
        if (buscado.isEmpty()) return "¿Qué app quieres que abra?"
        val match = apps.firstOrNull { norm(it.loadLabel(pm).toString()) == buscado }
            ?: apps.firstOrNull { norm(it.loadLabel(pm).toString()).contains(buscado) }
            ?: return "No encontré una app llamada $buscado."
        val launch = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
            ?: return "No pude abrir esa app."
        lanzar(ctx, launch)
        return "Abriendo ${match.loadLabel(pm)}."
    }

    private fun linterna(ctx: Context, encender: Boolean): String {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return "Tu celular no tiene flash."
        cm.setTorchMode(id, encender)
        return if (encender) "Linterna encendida." else "Linterna apagada."
    }

    private fun volumen(ctx: Context, t: String): String {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        return when {
            t.contains("silencio") || t.contains("silencia") -> {
                am.setStreamVolume(AudioManager.STREAM_MUSIC, 0, AudioManager.FLAG_SHOW_UI)
                "Volumen en silencio."
            }
            t.contains("sube") || t.contains("aumenta") || t.contains("mas") || t.contains("subir") -> {
                repeat(2) { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI) }
                "Volumen arriba."
            }
            t.contains("baja") || t.contains("menos") || t.contains("disminuye") || t.contains("bajar") -> {
                repeat(2) { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI) }
                "Volumen abajo."
            }
            else -> "Dime si subo o bajo el volumen."
        }
    }

    private fun hora(): String {
        val f = SimpleDateFormat("h:mm a", Locale("es", "HN"))
        return "Son las " + f.format(Date())
    }

    private fun buscarNumero(ctx: Context, nombre: String): String? {
        val limpio = nombre.trim()
        val soloNumero = limpio.replace(" ", "").replace("-", "")
        if (soloNumero.matches(Regex("\\+?\\d{6,15}"))) return soloNumero
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        val objetivo = norm(limpio)
        var mejor: String? = null
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            null, null, null
        )?.use { c ->
            while (c.moveToNext()) {
                val n = norm(c.getString(0) ?: "")
                val num = c.getString(1) ?: continue
                if (n == objetivo) return num
                if (mejor == null && n.contains(objetivo)) mejor = num
            }
        }
        return mejor
    }

    private fun llamar(ctx: Context, t: String): String {
        val nombre = t.replace(Regex("^(llama|llamar)( a la| a| al)? "), "").trim()
        if (ctx.checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            return "Necesito permiso para hacer llamadas."
        }
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED &&
            !nombre.replace(" ", "").matches(Regex("\\+?\\d{6,15}"))
        ) {
            return "Necesito permiso para ver tus contactos."
        }
        val numero = buscarNumero(ctx, nombre) ?: return "No encontré a $nombre en tus contactos."
        lanzar(ctx, Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(numero))))
        return "Llamando a $nombre."
    }

    private fun mandarMensaje(ctx: Context, original: String): String {
        val m = SMS_REGEX.find(norm(original)) ?: return "No entendí el mensaje."
        val nombre = m.groupValues[1].trim()
        // Para el texto uso la frase original (con tildes y mayúsculas)
        val textoOriginal = SMS_REGEX.find(original)?.groupValues?.get(2)?.trim() ?: m.groupValues[2].trim()
        if (ctx.checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            return "Necesito permiso para mandar mensajes."
        }
        val numero = buscarNumero(ctx, nombre)
            ?: return "No encontré a $nombre en tus contactos."
        val sms = ctx.getSystemService(SmsManager::class.java)
        val partes = sms.divideMessage(textoOriginal)
        sms.sendMultipartTextMessage(numero, null, partes, null, null)
        return "Mensaje enviado a $nombre."
    }
}
