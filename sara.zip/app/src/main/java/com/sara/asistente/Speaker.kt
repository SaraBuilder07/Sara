package com.sara.asistente

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

object Speaker {
    private var tts: TextToSpeech? = null
    private var listo = false

    @Volatile
    var hablando = false

    fun init(ctx: Context) {
        if (tts != null) return
        tts = TextToSpeech(ctx.applicationContext) { status ->
            val t = tts
            if (status == TextToSpeech.SUCCESS && t != null) {
                var r = t.setLanguage(Locale("es", "MX"))
                if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                    r = t.setLanguage(Locale("es", "ES"))
                }
                t.setPitch(1.15f)
                t.setSpeechRate(1.0f)
                t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        hablando = true
                    }

                    override fun onDone(utteranceId: String?) {
                        hablando = false
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        hablando = false
                    }
                })
                listo = true
            }
        }
    }

    fun decir(texto: String) {
        if (listo) {
            hablando = true
            val r = tts?.speak(texto, TextToSpeech.QUEUE_FLUSH, null, "sara")
            if (r != TextToSpeech.SUCCESS) hablando = false
        }
    }
}
