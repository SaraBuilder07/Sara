package com.sara.asistente

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract
import android.provider.Settings
import android.telephony.SmsManager
import java.text.Normalizer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Acciones {

    val ACTIVACION = Regex("(?:sara|zara|sarah)\\W*\\s+inici[ao]\\W*(.*)", RegexOption.IGNORE_CASE)

    private val SMS_REGEX = Regex(
        "(?:manda|mandar|mandale|mándale|env[ií]a|enviar|env[ií]ale|escribe|escribir|escr[ií]bele|escribele)" +
            "\\s+(?:un\\s+)?(?:mensaje|sms|texto)\\s+a\\s+(.+?)\\s+(?:diciendo|que diga|que dice|que)\\s+(.+)",
        RegexOption.IGNORE_CASE
    )

    // Verbos que indican el inicio de una nueva tarea dentro de una misma frase
    private const val VERBOS =
        "abre|abrir|abra|abras|lanza|lanzar|ejecuta|ejecutar|entra|enciende|encender|enciendas|prende|prender|prendas|" +
            "activa|activar|apaga|apagar|apagues|desactiva|desactivar|toma|tomar|tomes|saca|sacar|haz|hacer|" +
            "sube|subir|subas|baja|bajar|bajes|aumenta|disminuye|llama|llamar|llames|manda|mandar|envia|enviar|" +
            "cierra|cerrar|cierres|bloquea|bloquear|regresa|vuelve|silencia|dime|pon|ponme|muestra|muestrame"

    private val CONECTOR = Regex(
        "(?:\\s*,\\s*(?:y\\s+|e\\s+|luego\\s+|despues\\s+|entonces\\s+)?|" +
            "\\s+(?:y luego|y despues|y tambien|y ademas|luego|despues|ademas|tambien|entonces|y|e)\\s+)" +
            "(?=(?:$VERBOS)\\b)"
    )

    private val RELLENO = Regex(
        "^(?:(?:por favor|oye|ok|hey|sara|podrias|puedes|me puedes|me podrias|quiero que|necesito que|ahora|quiero|hola)\\s+)+"
    )

    private val ALIAS: List<List<String>> = listOf(
        listOf("whatsapp", "wasap", "guasap", "guatsap", "whatsap", "wats app", "whats app", "whats"),
        listOf("youtube", "yutub", "yutu", "you tube"),
        listOf("facebook", "feisbuk", "face"),
        listOf("instagram", "insta", "instagran"),
        listOf("tiktok", "tik tok"),
        listOf("chrome", "google chrome", "navegador", "internet"),
        listOf("camara", "camera"),
        listOf("galeria", "fotos"),
        listOf("ajustes", "configuracion", "configuraciones", "settings", "ajuste"),
        listOf("telefono", "llamadas", "marcador"),
        listOf("mensajes", "sms"),
        listOf("calculadora", "calculador"),
        listOf("reloj", "alarma", "alarmas"),
        listOf("maps", "mapas", "google maps"),
        listOf("play store", "tienda", "playstore"),
        listOf("telegram", "telegran"),
        listOf("spotify", "espotifai"),
        listOf("netflix", "netfli")
    )

    fun norm(s: String): String =
        Normalizer.normalize(s.lowercase(Locale("es")), Normalizer.Form.NFD)
            .replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
            .trim()

    fun quitarActivacion(s: String): String =
        ACTIVACION.find(s)?.groupValues?.get(1)?.trim() ?: s.trim()

    private fun clave(s: String): String = norm(s).replace(Regex("[^a-z0-9]"), "")

    private fun limpiarPuntuacion(s: String): String =
        s.replace(Regex("[.¡!¿?]"), " ").replace(Regex("\\s+"), " ").trim()

    /** Ejecuta una frase (puede traer varias tareas) en segundo plano y avisa al terminar. */
    fun ejecutarAsync(ctx: Context, texto: String, alTerminar: (String) -> Unit) {
        val app = ctx.applicationContext
        Thread {
            val r = try {
                ejecutar(app, texto)
            } catch (e: Exception) {
                "No pude hacerlo."
            }
            Handler(Looper.getMainLooper()).post { alTerminar(r) }
        }.start()
    }

    fun ejecutar(ctx: Context, original: String): String {
        val sms = SMS_REGEX.find(original)
        var antes = if (sms != null) original.substring(0, sms.range.first) else original
        antes = antes.replace(Regex("(?i)[\\s,]+(?:y|e|luego|despues|después|entonces)\\s*$"), "")

        val tareas = ArrayList<String>()
        val t0 = limpiarPuntuacionConComas(norm(antes))
        if (t0.isNotBlank()) {
            CONECTOR.split(t0).map { it.trim() }.filter { it.isNotEmpty() }.forEach { tareas.add(it) }
        }
        if (sms != null) tareas.add(original.substring(sms.range.first))
        if (tareas.isEmpty()) return "No te escuché."

        val respuestas = ArrayList<String>()
        tareas.forEachIndexed { i, tarea ->
            val r = if (SMS_REGEX.containsMatchIn(tarea)) mandarMensaje(ctx, tarea) else ejecutarUno(ctx, tarea)
            respuestas.add(r)
            if (i < tareas.size - 1) {
                val espera = if (canonizar(limpiar(tarea)).startsWith("abre ")) 2200L else 900L
                Thread.sleep(espera)
            }
        }
        return respuestas.joinToString(" ")
    }

    private fun limpiarPuntuacionConComas(s: String): String =
        s.replace(Regex("[.¡!¿?]"), " ").replace(Regex("\\s+"), " ").trim()

    private fun limpiar(s: String): String {
        var t = limpiarPuntuacion(norm(s).replace(",", " "))
        t = t.replace(RELLENO, "")
        t = t.replace(Regex("\\s+por favor$"), "")
        return t.trim()
    }

    private fun canonizar(t: String): String =
        t.replace(Regex("^(?:abrir|abra|abras|abreme|lanza|lanzar|ejecuta|ejecutar|entra a|entra en|muestrame)\\s+"), "abre ")

    private fun ejecutarUno(ctx: Context, seg: String): String {
        val t = canonizar(limpiar(seg))
        return try {
            when {
                t.isEmpty() -> "No te escuché."
                t.startsWith("llama ") || t.startsWith("llamar ") || t.startsWith("llames ") -> llamar(ctx, t)
                t.contains("wifi") || t.contains("wi fi") ->
                    abrirAjuste(ctx, Settings.ACTION_WIFI_SETTINGS, "el wifi")
                t.contains("bluetooth") ->
                    abrirAjuste(ctx, Settings.ACTION_BLUETOOTH_SETTINGS, "el bluetooth")
                t.contains("linterna") || t.contains("lampara") || t.contains("flash") ->
                    linterna(ctx, !(t.contains("apag") || t.contains("desactiv")))
                t.startsWith("abre ") -> abrirApp(ctx, t.substringAfter(" "))
                t.contains("captura") || t.contains("pantallazo") || t.contains("screenshot") ->
                    global(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT, "Captura tomada.")
                t.contains("recientes") || t.contains("cierra todo") || t.contains("cerrar todo") ||
                    t.contains("cierra las apps") || t.contains("cerrar apps") || t.contains("cierra las aplicaciones") ->
                    global(AccessibilityService.GLOBAL_ACTION_RECENTS, "Aquí están tus apps recientes. Desliza para cerrarlas.")
                t.startsWith("cierra") || t.startsWith("cerrar") || t.startsWith("cierres") ||
                    t.contains("pantalla de inicio") || t == "inicio" || t.contains("ve al inicio") ->
                    global(AccessibilityService.GLOBAL_ACTION_HOME, "Listo, estás en el inicio.")
                t.contains("atras") || t.startsWith("regresa") || t.startsWith("vuelve") ->
                    global(AccessibilityService.GLOBAL_ACTION_BACK, "Listo.")
                t.contains("notificaciones") ->
                    global(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS, "Aquí están tus notificaciones.")
                t.contains("bloquea") ->
                    global(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN, "Pantalla bloqueada.")
                t.contains("volumen") || t.contains("silencio") || t.contains("silencia") -> volumen(ctx, t)
                t.contains("bateria") -> bateria(ctx)
                t.contains("que dia") || t.contains("la fecha") || t.contains("que fecha") -> fecha()
                t.contains("que hora") || t.contains("la hora") -> hora()
                t.contains("ayuda") || t.contains("que puedes hacer") -> AYUDA
                t.contains("gracias") -> "Para eso estoy."
                t.startsWith("hola") -> "Hola, soy Sara. ¿En qué te ayudo?"
                else -> "No entendí eso. Di ayuda para saber qué puedo hacer."
            }
        } catch (e: Exception) {
            "No pude hacerlo."
        }
    }

    private const val AYUDA =
        "Puedo abrir apps, encender o apagar la linterna, tomar capturas, ir al inicio, ver apps recientes, " +
            "ajustar el volumen, llamar a un contacto, mandar mensajes y decirte la hora, la fecha o la batería. " +
            "Y puedo hacer varias cosas a la vez, por ejemplo: abre WhatsApp y enciende la linterna."

    // Lanza una actividad desde el servicio de accesibilidad si está activo (Android restringe abrir apps desde el fondo)
    private fun lanzar(ctx: Context, intent: Intent) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val c: Context = SaraAccessibilityService.instancia ?: ctx
        c.startActivity(intent)
    }

    private fun global(accion: Int, ok: String): String {
        val s = SaraAccessibilityService.instancia
            ?: return "Necesito que actives mi servicio de accesibilidad en Ajustes."
        return if (s.performGlobalAction(accion)) ok else "No pude hacerlo."
    }

    private fun abrirAjuste(ctx: Context, accion: String, nombre: String): String {
        lanzar(ctx, Intent(accion))
        return "Android no me deja cambiar $nombre sola, pero te abrí sus ajustes."
    }

    private fun distancia(a: String, b: String): Int {
        val d = Array(a.length + 1) { IntArray(b.length + 1) }
        for (i in 0..a.length) d[i][0] = i
        for (j in 0..b.length) d[0][j] = j
        for (i in 1..a.length) for (j in 1..b.length) {
            val c = if (a[i - 1] == b[j - 1]) 0 else 1
            d[i][j] = minOf(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + c)
        }
        return d[a.length][b.length]
    }

    private fun abrirApp(ctx: Context, nombre: String): String {
        val pm = ctx.packageManager
        val filtro = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps: List<Pair<ResolveInfo, String>> = pm.queryIntentActivities(filtro, 0)
            .map { Pair(it, clave(it.loadLabel(pm).toString())) }

        var buscado = norm(nombre)
        for (p in listOf("la aplicacion de ", "la app de ", "la aplicacion ", "la app ", "aplicacion ", "app ", "la ", "el ")) {
            if (buscado.startsWith(p)) {
                buscado = buscado.removePrefix(p)
                break
            }
        }
        val key = clave(buscado)
        if (key.isEmpty()) return "¿Qué app quieres que abra?"

        val grupo = ALIAS.firstOrNull { g -> g.any { clave(it) == key } }
        val candidatos = grupo?.map { clave(it) } ?: listOf(key)

        var match: Pair<ResolveInfo, String>? = null
        for (c in candidatos) {
            match = apps.firstOrNull { it.second == c }
            if (match != null) break
        }
        if (match == null) {
            for (c in candidatos) {
                if (c.length < 3) continue
                match = apps.filter { it.second.contains(c) }.minByOrNull { it.second.length }
                if (match != null) break
            }
        }
        if (match == null) {
            match = apps.filter { it.second.length >= 4 && key.contains(it.second) }.maxByOrNull { it.second.length }
        }
        if (match == null && key.length >= 5) {
            match = apps.filter { distancia(it.second, key) <= 2 }.minByOrNull { distancia(it.second, key) }
        }
        val elegido = match ?: return "No encontré una app llamada $buscado."
        val launch = pm.getLaunchIntentForPackage(elegido.first.activityInfo.packageName)
            ?: return "No pude abrir esa app."
        lanzar(ctx, launch)
        return "Abriendo ${elegido.first.loadLabel(pm)}."
    }

    private fun linterna(ctx: Context, encender: Boolean): String {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return "Tu celular no tiene flash."
        cm.setTorchMode(id, encender)
        return if (encender) "Linterna encendida." else "Linterna apagada."
    }

    private fun volumen(ctx: Context, t: String): String {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val num = Regex("(\\d{1,3})").find(t)?.groupValues?.get(1)?.toIntOrNull()
        return when {
            num != null -> {
                val p = num.coerceIn(0, 100)
                am.setStreamVolume(AudioManager.STREAM_MUSIC, (max * p / 100.0).toInt(), AudioManager.FLAG_SHOW_UI)
                "Volumen al $p por ciento."
            }
            t.contains("maximo") || t.contains("al tope") -> {
                am.setStreamVolume(AudioManager.STREAM_MUSIC, max, AudioManager.FLAG_SHOW_UI)
                "Volumen al máximo."
            }
            t.contains("minimo") || t.contains("silencio") || t.contains("silencia") || t.contains("mute") -> {
                am.setStreamVolume(AudioManager.STREAM_MUSIC, 0, AudioManager.FLAG_SHOW_UI)
                "Volumen en silencio."
            }
            t.contains("sube") || t.contains("aumenta") || t.contains("mas") || t.contains("subir") || t.contains("subas") -> {
                repeat(2) { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI) }
                "Volumen arriba."
            }
            t.contains("baja") || t.contains("menos") || t.contains("disminuye") || t.contains("bajar") || t.contains("bajes") -> {
                repeat(2) { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI) }
                "Volumen abajo."
            }
            else -> "Dime si subo o bajo el volumen."
        }
    }

    private fun hora(): String {
        val f = SimpleDateFormat("h:mm a", Locale("es", "HN"))
        return "Son las " + f.format(Date())
    }

    private fun fecha(): String {
        val f = SimpleDateFormat("EEEE d 'de' MMMM 'de' yyyy", Locale("es", "HN"))
        return "Hoy es " + f.format(Date())
    }

    private fun bateria(ctx: Context): String {
        val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val nivel = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        return "Tienes $nivel por ciento de batería."
    }

    private fun buscarNumero(ctx: Context, nombre: String): String? {
        val limpio = nombre.trim()
        val soloNumero = limpio.replace(" ", "").replace("-", "")
        if (soloNumero.matches(Regex("\\+?\\d{6,15}"))) return soloNumero
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        val objetivo = norm(limpio)
        var mejor: String? = null
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            null, null, null
        )?.use { c ->
            while (c.moveToNext()) {
                val n = norm(c.getString(0) ?: "")
                val num = c.getString(1) ?: continue
                if (n == objetivo) return num
                if (mejor == null && n.contains(objetivo)) mejor = num
            }
        }
        return mejor
    }

    private fun llamar(ctx: Context, t: String): String {
        val nombre = t.replace(Regex("^(llama|llamar|llames)( a la| a| al)? "), "").trim()
        if (ctx.checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            return "Necesito permiso para hacer llamadas."
        }
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED &&
            !nombre.replace(" ", "").matches(Regex("\\+?\\d{6,15}"))
        ) {
            return "Necesito permiso para ver tus contactos."
        }
        val numero = buscarNumero(ctx, nombre) ?: return "No encontré a $nombre en tus contactos."
        lanzar(ctx, Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(numero))))
        return "Llamando a $nombre."
    }

    private fun mandarMensaje(ctx: Context, original: String): String {
        val m = SMS_REGEX.find(original) ?: return "No entendí el mensaje."
        val nombre = m.groupValues[1].trim()
        val texto = m.groupValues[2].trim()
        if (ctx.checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            return "Necesito permiso para mandar mensajes."
        }
        val numero = buscarNumero(ctx, nombre)
            ?: return "No encontré a $nombre en tus contactos."
        val sms = ctx.getSystemService(SmsManager::class.java)
        val partes = sms.divideMessage(texto)
        sms.sendMultipartTextMessage(numero, null, partes, null, null)
        return "Mensaje enviado a $nombre."
    }
}
