package com.sara.asistente

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var registro: TextView
    private lateinit var scroll: ScrollView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun agregar(texto: String) {
        runOnUiThread {
            registro.append(texto + "\n\n")
            scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
        }
    }

    private fun boton(texto: String, accion: () -> Unit): Button {
        val b = Button(this)
        b.text = texto
        b.isAllCaps = false
        b.setOnClickListener { accion() }
        return b
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Speaker.init(this)

        val raiz = LinearLayout(this)
        raiz.orientation = LinearLayout.VERTICAL
        raiz.setBackgroundColor(Color.parseColor("#101820"))
        raiz.setPadding(dp(16), dp(36), dp(16), dp(16))

        val titulo = TextView(this)
        titulo.text = "Sara"
        titulo.textSize = 30f
        titulo.setTextColor(Color.parseColor("#7FDBFF"))
        raiz.addView(titulo)

        scroll = ScrollView(this)
        registro = TextView(this)
        registro.setTextColor(Color.WHITE)
        registro.textSize = 15f
        registro.text = "Hola, soy Sara. Escríbeme una orden o activa la escucha y di \"Sara inicia\".\n\n"
        scroll.addView(registro)
        raiz.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val entrada = EditText(this)
        entrada.hint = "Escríbele una orden a Sara"
        entrada.setTextColor(Color.WHITE)
        entrada.setHintTextColor(Color.GRAY)
        raiz.addView(entrada)

        raiz.addView(boton("Enviar orden") {
            val texto = Acciones.quitarActivacion(entrada.text.toString())
            if (texto.isNotEmpty()) {
                agregar("Tú: $texto")
                Acciones.ejecutarAsync(this, texto) { r ->
                    agregar("Sara: $r")
                    Speaker.decir(r)
                }
                entrada.setText("")
            }
        })
        raiz.addView(boton("Activar escucha (Sara inicia)") {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Primero toca \"1. Dar permisos\"", Toast.LENGTH_LONG).show()
            } else {
                startForegroundService(Intent(this, SaraService::class.java))
            }
        })
        raiz.addView(boton("Detener escucha") {
            stopService(Intent(this, SaraService::class.java))
        })
        raiz.addView(boton("1. Dar permisos") {
            requestPermissions(
                arrayOf(
                    Manifest.permission.RECORD_AUDIO,
                    Manifest.permission.CALL_PHONE,
                    Manifest.permission.SEND_SMS,
                    Manifest.permission.READ_CONTACTS,
                    Manifest.permission.POST_NOTIFICATIONS
                ), 1
            )
        })
        raiz.addView(boton("2. Activar accesibilidad (capturas, inicio...)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        raiz.addView(boton("3. Permitir mostrar sobre otras apps (abrir apps)") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        })

        setContentView(raiz)
    }

    override fun onResume() {
        super.onResume()
        Estado.oyente = { agregar(it) }
    }

    override fun onPause() {
        Estado.oyente = null
        super.onPause()
    }
}
