plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.sara.asistente"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.sara.asistente"
        minSdk = 26
        targetSdk = 34
        // GitHub sube este número en cada compilación, así Android acepta las actualizaciones
        versionCode = System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 1
        versionName = "1.1"
    }

    // Llave fija: todas las versiones de Sara se firman igual y se instalan encima sin desinstalar
    signingConfigs {
        getByName("debug") {
            storeFile = file("sara.keystore")
            storePassword = "sara123"
            keyAlias = "sara"
            keyPassword = "sara123"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
